let screens = document.querySelectorAll(".container") 
let again = document.querySelector(".again-btn")
let start = document.querySelector(".board-btn")
let time = document.getElementById("time")
let timeEl = 0
let ulu = document.getElementById("board-list")
console.log(ulu)
let container = document.getElementById("game")
let cardsCount = 0
let firstCard = null
let secondCard = null
let cardsArray = []
let cardsNumberArray = []
let timer;
class Card{
    _open = false
    _success = false
    constructor(container, number, action){
        this.card=document.createElement("div")
        this.card.classList.add("card")
        this.card.textContent=number
        this.number=number
        this.card.addEventListener("click",()=>{
            if(this._open==this.open){
                this.open=true
                action(this)
            }
        })
        container.append(this.card)
    }
    set open(value){
        this._open=value
        if(value){
            this.card.classList.add("open")
        }
        else{
            this.card.classList.remove("open")
        }
    }
    get open(){
        return this._open
    }
    set success(value){
        this._success=value
        if(value){
            this.card.classList.add("success")
        }
        else{
            this.card.classList.remove("success")
        }
    }
    get success(){
        return this._success
    }
}
start.addEventListener("click",()=>{
    timeEl=parseInt(60)
    startGame()
})
function startGame(){
    screens[1].classList.add("up")
    timer=setInterval(timeer,1000)
    setTime(timeEl)
    createCards()
    time.parentNode.classList.remove("hide")
    // again.classList.remove("active")
}
again.addEventListener("click",(event)=>{
    event.preventDefault()
    container.innerHTML=""
    cardsCount=parseInt(6)
    timeEl=parseInt(60)
    startGame()
})
function board(element){
    if(element>=16){
        container.style.width="400px"
    } else if(element>=24){
        container.style.width="600px"
    } else if(element>=32){
        container.style.width="800px"
    }
}
ulu.addEventListener("click",(event)=>{
    if(event.target.classList.contains('board-btn')){
        cardsCount=parseInt(6)
        board(cardsCount)
        screens[0].innerHTML=""
    }
})
ulu.addEventListener("click",(event)=>{
    if(event.target.classList.contains('board-btn')){
        timeEl=parseInt(10)
        startGame()
    }
})
function timeer(){
    if(timeEl===0){
        timeStop()
    } else {
        let currentTime = --timeEl
        setTime(currentTime)
    }

}

function setTime(value){
    time.innerHTML=`у вас осталось ${value} секунд`
}
function timeStop(){
    stopGame()
    timer=clearInterval(timer)
    timeEl=0
    container.innerHTML=`<h1> время вышло</h1>`
}
function stopGame(){
    cardsArray=[]
    cardsNumberArray=[]
    firstCard=null
    secondCard=null
    cardsCount=0
    timer=clearInterval(timer)
    time.parentNode.classList.add("hide")
    // again.classList.add("active")
}
function createCards(){
    for(let i = 1;i<=cardsCount/2;i++){
        cardsNumberArray.push(i)
        cardsNumberArray.push(i)
    }
    cardsNumberArray=cardsNumberArray.sort(()=> Math.random()-0.5)
    for(const cardNum of cardsNumberArray){
        cardsArray.push(new Card(container, cardNum, flip))
    }
}
function flip(){
    return null
}